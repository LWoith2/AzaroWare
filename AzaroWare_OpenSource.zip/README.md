# AzaroWare

CS2 external overlay by **lyrickgg**

Discord: https://discord.gg/UNGu6QpdX

## This repository

This tree is a **restricted public snapshot**.

- Menu / UI / credits / config layout are included
- Memory attach, entity walk, aim, and spectator resolution are **not** included

Full source and builds are shared with Discord members only.

## Credits

- **lyrickgg** — author
- [sezzyaep/CS2-OFFSETS](https://github.com/sezzyaep/CS2-OFFSETS) — offsets
- [Dear ImGui](https://github.com/ocornut/imgui) — UI (MIT)

## Legal

For educational / private use. You are responsible for how you use this software.
