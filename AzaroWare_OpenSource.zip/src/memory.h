#pragma once
#include <Windows.h>
#include <cstdint>
#include <string>

// Public stub — core RPM helpers are private.
// Full build available to members: discord.gg/UNGu6QpdX
class Memory {
public:
    HANDLE hProcess = nullptr;
    DWORD pid = 0;
    uintptr_t clientBase = 0;

    bool Attach(const wchar_t* processName); // private
    uintptr_t GetModuleBase(const wchar_t* moduleName); // private

    template<typename T>
    T Read(uintptr_t address) const {
        T v{};
        // [private]
        (void)address;
        return v;
    }

    template<typename T>
    bool Write(uintptr_t address, const T& value) const {
        (void)address; (void)value;
        return false; // [private]
    }

    std::string ReadString(uintptr_t address, size_t maxLen = 32) const {
        (void)address; (void)maxLen;
        return {};
    }

    void Close();
};
