#pragma once
#include <cmath>
#include <cstdint>
#include <string>

struct Vec3 {
    float x = 0.f, y = 0.f, z = 0.f;
    Vec3() = default;
    Vec3(float x, float y, float z) : x(x), y(y), z(z) {}
    Vec3 operator+(const Vec3& o) const { return { x + o.x, y + o.y, z + o.z }; }
    Vec3 operator-(const Vec3& o) const { return { x - o.x, y - o.y, z - o.z }; }
    float Length() const { return std::sqrt(x * x + y * y + z * z); }
};

struct Vec2 {
    float x = 0.f, y = 0.f;
};

struct Matrix4x4 {
    float m[4][4]{};
};

inline bool WorldToScreen(const Vec3& world, Vec2& screen, const Matrix4x4& vm, int width, int height) {
    float w = vm.m[3][0] * world.x + vm.m[3][1] * world.y + vm.m[3][2] * world.z + vm.m[3][3];
    if (w < 0.001f) return false;
    float x = vm.m[0][0] * world.x + vm.m[0][1] * world.y + vm.m[0][2] * world.z + vm.m[0][3];
    float y = vm.m[1][0] * world.x + vm.m[1][1] * world.y + vm.m[1][2] * world.z + vm.m[1][3];
    float invW = 1.0f / w;
    x *= invW; y *= invW;
    screen.x = (width  * 0.5f) + (x * width  * 0.5f);
    screen.y = (height * 0.5f) - (y * height * 0.5f);
    return true;
}

struct Player {
    Vec3 origin{};
    Vec3 head{};
    int health = 0;
    int armor = 0;
    int team = 0;
    bool alive = false;
    bool onScreen = false;
    std::string name;
    std::string weapon;
    Vec2 screenFeet{};
    Vec2 screenHead{};
    float distance = 0.f;
};

inline const char* WeaponNameFromId(int id) {
    switch (id) {
    case 1: return "DEAGLE"; case 2: return "ELITE"; case 3: return "FIVESEVEN";
    case 4: return "GLOCK"; case 7: return "AK47"; case 8: return "AUG";
    case 9: return "AWP"; case 10: return "FAMAS"; case 11: return "G3SG1";
    case 13: return "GALIL"; case 14: return "M249"; case 16: return "M4A4";
    case 17: return "MAC10"; case 19: return "P90"; case 23: return "MP5";
    case 24: return "UMP45"; case 25: return "XM1014"; case 26: return "BIZON";
    case 27: return "MAG7"; case 28: return "NEGEV"; case 29: return "SAWEDOFF";
    case 30: return "TEC9"; case 31: return "ZEUS"; case 32: return "P2000";
    case 33: return "MP7"; case 34: return "MP9"; case 35: return "NOVA";
    case 36: return "P250"; case 38: return "SCAR20"; case 39: return "SG553";
    case 40: return "SSG08"; case 42: return "KNIFE"; case 43: return "FLASH";
    case 44: return "HE"; case 45: return "SMOKE"; case 46: return "MOLOTOV";
    case 47: return "DECOY"; case 48: return "INCEND"; case 49: return "C4";
    case 60: return "M4A1-S"; case 61: return "USP-S"; case 63: return "CZ75";
    case 64: return "REVOLVER";
    default: return "GUN";
    }
}
