#pragma once
#include <cstddef>
#include <cstdint>

// sezzyaep/CS2-OFFSETS build 14194 (2026-10-30)
namespace off {
    constexpr std::ptrdiff_t dwEntityList            = 0x271EB28;
    constexpr std::ptrdiff_t dwLocalPlayerPawn       = 0x25698C8;
    constexpr std::ptrdiff_t dwViewMatrix            = 0x256F1D0;
    constexpr std::ptrdiff_t dwLocalPlayerController = 0x25413F8;
    constexpr std::ptrdiff_t dwViewAngles            = 0x2580008;

    constexpr std::ptrdiff_t m_iHealth       = 0x34C;
    constexpr std::ptrdiff_t m_lifeState     = 0x354;
    constexpr std::ptrdiff_t m_iTeamNum      = 0x3E7;
    constexpr std::ptrdiff_t m_vOldOrigin    = 0x14A4;
    constexpr std::ptrdiff_t m_pGameSceneNode= 0x330;
    constexpr std::ptrdiff_t m_vecViewOffset = 0xF60;
    constexpr std::ptrdiff_t m_ArmorValue    = 0x1ED0;

    constexpr std::ptrdiff_t m_hPlayerPawn   = 0x92C;
    constexpr std::ptrdiff_t m_hObserverPawn = 0x930;
    constexpr std::ptrdiff_t m_bPawnIsAlive  = 0x934;
    constexpr std::ptrdiff_t m_iszPlayerName = 0x6FC;

    constexpr std::ptrdiff_t m_modelState    = 0x140;
    constexpr std::ptrdiff_t m_boneArray     = 0x80;
    constexpr std::ptrdiff_t m_nodeToWorld   = 0x10;

    constexpr std::ptrdiff_t m_pWeaponServices   = 0x12F0;
    constexpr std::ptrdiff_t m_pObserverServices = 0x1308;
    constexpr std::ptrdiff_t m_hActiveWeapon     = 0x60;
    constexpr std::ptrdiff_t m_iObserverMode     = 0x48;
    constexpr std::ptrdiff_t m_hObserverTarget   = 0x4C;

    constexpr std::ptrdiff_t m_AttributeManager     = 0x14C8;
    constexpr std::ptrdiff_t m_Item                 = 0x50;
    constexpr std::ptrdiff_t m_iItemDefinitionIndex = 0x1BA;
}
