// AzaroWare — CS2 external
// by lyrickgg  |  discord.gg/UNGu6QpdX
// INSERT = menu | END = exit | RMB = aimbot

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <shellapi.h>
#include <d3d11.h>
#include <dxgi.h>
#include <string>
#include <vector>
#include <chrono>
#include <thread>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cstdio>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "memory.h"
#include "offsets.h"
#include "sdk.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "shell32.lib")

// -------------------- globals --------------------
Memory mem;
ID3D11Device*           g_pd3dDevice = nullptr;
ID3D11DeviceContext*    g_pd3dDeviceContext = nullptr;
IDXGISwapChain*         g_pSwapChain = nullptr;
ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;
HWND  g_hwnd = nullptr;
int   g_width = 0, g_height = 0;

// Visuals
bool  g_menuOpen = true;
bool  g_espBox = true;
bool  g_espBoxFilled = false;
bool  g_espCorner = false;
bool  g_espHealth = true;
bool  g_espArmor = false;
bool  g_espName = true;
bool  g_espWeapon = true;
bool  g_espDistance = true;
bool  g_espSnapline = false;
bool  g_teamCheck = true;
float g_boxThickness = 1.5f;
float g_boxColor[4]  = { 0.25f, 0.55f, 1.f, 1.f };
float g_enemyColor[4]= { 1.f, 0.25f, 0.25f, 1.f };
float g_teamColor[4] = { 0.25f, 0.75f, 1.f, 1.f };
float g_nameColor[4] = { 1.f, 1.f, 1.f, 1.f };
float g_weaponColor[4]= { 0.6f, 0.85f, 1.f, 1.f };

// Aimbot
bool  g_aimbot = true;
bool  g_drawFov = true;
float g_aimFov = 90.f;
float g_aimSmooth = 5.f;
int   g_aimKey = VK_RBUTTON;
bool  g_aimHead = true;

// Misc
bool  g_specList = true;
std::vector<std::string> g_spectators;

// Menu / perf — overlay must stay LOW fps or it steals GPU from CS2
float g_menuAlpha = 0.f;
float g_accent[4] = { 0.20f, 0.45f, 1.0f, 1.f };
int   g_overlayFps = 60;      // cap overlay redraw (30/60/90) — main lag fix
bool  g_vsync = false;        // never vsync overlay against a 144hz game
float g_menuAnim = 0.f;
int   g_menuTab = 0;
bool  g_styleDirty = true;
int   g_frameCounter = 0;

int g_lastPlayerCount = 0;
std::vector<Player> g_lastPlayers;

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// -------------------- config path --------------------
std::string ConfigPath() {
    char appdata[MAX_PATH]{};
    if (!GetEnvironmentVariableA("APPDATA", appdata, MAX_PATH))
        return "AzaroWare.ini";
    std::string dir = std::string(appdata) + "\\AzaroWare";
    CreateDirectoryA(dir.c_str(), nullptr);
    return dir + "\\config.ini";
}

void SaveConfig() {
    std::ofstream f(ConfigPath());
    if (!f) return;
    f << "espBox=" << g_espBox << "\n";
    f << "espBoxFilled=" << g_espBoxFilled << "\n";
    f << "espCorner=" << g_espCorner << "\n";
    f << "espHealth=" << g_espHealth << "\n";
    f << "espArmor=" << g_espArmor << "\n";
    f << "espName=" << g_espName << "\n";
    f << "espWeapon=" << g_espWeapon << "\n";
    f << "espDistance=" << g_espDistance << "\n";
    f << "espSnapline=" << g_espSnapline << "\n";
    f << "teamCheck=" << g_teamCheck << "\n";
    f << "boxThickness=" << g_boxThickness << "\n";
    f << "aimbot=" << g_aimbot << "\n";
    f << "drawFov=" << g_drawFov << "\n";
    f << "aimFov=" << g_aimFov << "\n";
    f << "aimSmooth=" << g_aimSmooth << "\n";
    f << "aimHead=" << g_aimHead << "\n";
    f << "specList=" << g_specList << "\n";
    f << "overlayFps=" << g_overlayFps << "\n";
    f << "vsync=" << g_vsync << "\n";
    auto dump4 = [&](const char* k, float* c) {
        f << k << "=" << c[0] << "," << c[1] << "," << c[2] << "," << c[3] << "\n";
    };
    dump4("enemyColor", g_enemyColor);
    dump4("teamColor", g_teamColor);
    dump4("nameColor", g_nameColor);
    dump4("weaponColor", g_weaponColor);
    dump4("accent", g_accent);
}

void LoadConfig() {
    std::ifstream f(ConfigPath());
    if (!f) return;
    std::string line;
    while (std::getline(f, line)) {
        auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq);
        std::string v = line.substr(eq + 1);
        auto b = [&](const char* n) { return k == n && (v == "1" || v == "true"); };
        auto bf = [&](const char* n, bool& o) { if (k == n) o = (v == "1" || v == "true"); };
        auto ff = [&](const char* n, float& o) { if (k == n) o = (float)atof(v.c_str()); };
        auto ii = [&](const char* n, int& o) { if (k == n) o = atoi(v.c_str()); };
        bf("espBox", g_espBox); bf("espBoxFilled", g_espBoxFilled); bf("espCorner", g_espCorner);
        bf("espHealth", g_espHealth); bf("espArmor", g_espArmor); bf("espName", g_espName);
        bf("espWeapon", g_espWeapon); bf("espDistance", g_espDistance); bf("espSnapline", g_espSnapline);
        bf("teamCheck", g_teamCheck); bf("aimbot", g_aimbot); bf("drawFov", g_drawFov); bf("aimHead", g_aimHead); bf("specList", g_specList);
        bf("vsync", g_vsync);
        ff("boxThickness", g_boxThickness); ff("aimFov", g_aimFov); ff("aimSmooth", g_aimSmooth);
        ii("overlayFps", g_overlayFps);
        auto load4 = [&](const char* n, float* c) {
            if (k != n) return;
            sscanf_s(v.c_str(), "%f,%f,%f,%f", &c[0], &c[1], &c[2], &c[3]);
        };
        load4("enemyColor", g_enemyColor); load4("teamColor", g_teamColor);
        load4("nameColor", g_nameColor); load4("weaponColor", g_weaponColor); load4("accent", g_accent);
    }
}

// -------------------- theme --------------------
void ApplyAzaroStyle() {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 10.f;
    s.ChildRounding = 8.f;
    s.FrameRounding = 6.f;
    s.GrabRounding = 6.f;
    s.PopupRounding = 8.f;
    s.ScrollbarRounding = 8.f;
    s.TabRounding = 6.f;
    s.WindowBorderSize = 1.f;
    s.FrameBorderSize = 0.f;
    s.WindowPadding = ImVec2(14, 12);
    s.FramePadding = ImVec2(10, 6);
    s.ItemSpacing = ImVec2(10, 8);
    s.ScrollbarSize = 10.f;
    s.GrabMinSize = 10.f;

    ImVec4* c = s.Colors;
    ImVec4 bg      = ImVec4(0.04f, 0.05f, 0.08f, 0.96f);
    ImVec4 bg2     = ImVec4(0.07f, 0.09f, 0.14f, 1.f);
    ImVec4 accent  = ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f);
    ImVec4 accentD = ImVec4(g_accent[0] * 0.6f, g_accent[1] * 0.6f, g_accent[2] * 0.7f, 1.f);

    c[ImGuiCol_WindowBg] = bg;
    c[ImGuiCol_ChildBg] = bg2;
    c[ImGuiCol_PopupBg] = bg;
    c[ImGuiCol_Border] = ImVec4(0.15f, 0.25f, 0.45f, 0.6f);
    c[ImGuiCol_FrameBg] = ImVec4(0.08f, 0.10f, 0.16f, 1.f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.12f, 0.16f, 0.28f, 1.f);
    c[ImGuiCol_FrameBgActive] = accentD;
    c[ImGuiCol_TitleBg] = ImVec4(0.03f, 0.04f, 0.07f, 1.f);
    c[ImGuiCol_TitleBgActive] = ImVec4(0.05f, 0.08f, 0.16f, 1.f);
    c[ImGuiCol_CheckMark] = accent;
    c[ImGuiCol_SliderGrab] = accent;
    c[ImGuiCol_SliderGrabActive] = ImVec4(0.4f, 0.65f, 1.f, 1.f);
    c[ImGuiCol_Button] = ImVec4(0.10f, 0.18f, 0.35f, 1.f);
    c[ImGuiCol_ButtonHovered] = accentD;
    c[ImGuiCol_ButtonActive] = accent;
    c[ImGuiCol_Header] = ImVec4(0.10f, 0.18f, 0.35f, 1.f);
    c[ImGuiCol_HeaderHovered] = accentD;
    c[ImGuiCol_HeaderActive] = accent;
    c[ImGuiCol_Tab] = ImVec4(0.06f, 0.08f, 0.14f, 1.f);
    c[ImGuiCol_TabHovered] = accentD;
    c[ImGuiCol_TabSelected] = accent;              // ImGui 1.90.9+ (was TabActive)
    c[ImGuiCol_TabSelectedOverline] = accent;
    c[ImGuiCol_TabDimmed] = ImVec4(0.05f, 0.06f, 0.10f, 1.f);
    c[ImGuiCol_TabDimmedSelected] = accentD;
    c[ImGuiCol_Separator] = ImVec4(0.15f, 0.25f, 0.45f, 0.5f);
    c[ImGuiCol_Text] = ImVec4(0.90f, 0.93f, 1.f, 1.f);
    c[ImGuiCol_TextDisabled] = ImVec4(0.45f, 0.50f, 0.60f, 1.f);
}

// -------------------- DX helpers --------------------
void CreateRenderTarget() {
    ID3D11Texture2D* pBackBuffer = nullptr;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    if (pBackBuffer) {
        g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
        pBackBuffer->Release();
    }
}
void CleanupRenderTarget() {
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
}
bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate = { 60, 1 };
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    D3D_FEATURE_LEVEL fl;
    const D3D_FEATURE_LEVEL fls[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    if (D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        fls, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &fl, &g_pd3dDeviceContext) != S_OK)
        return false;
    CreateRenderTarget();
    return true;
}
void CleanupDeviceD3D() {
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;
    switch (msg) {
    case WM_SIZE:
        if (g_pd3dDevice && wParam != SIZE_MINIMIZED) {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, LOWORD(lParam), HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
            g_width = LOWORD(lParam); g_height = HIWORD(lParam);
        }
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

// -------------------- entities --------------------
constexpr int kEntStride = 0x70;

uintptr_t GetEntityList() {
    return mem.Read<uintptr_t>(mem.clientBase + off::dwEntityList);
}

uintptr_t EntityFromHandle(uintptr_t list, uint32_t handle) {
    if (!handle || !list) return 0;
    uintptr_t entry = mem.Read<uintptr_t>(list + 8 * ((handle & 0x7FFF) >> 9) + 16);
    if (!entry) return 0;
    return mem.Read<uintptr_t>(entry + kEntStride * (handle & 0x1FF));
}

uintptr_t GetEntityController(uintptr_t list, int index) {
    uintptr_t entry = mem.Read<uintptr_t>(list + (8 * ((index & 0x7FFF) >> 9) + 16));
    if (!entry) return 0;
    return mem.Read<uintptr_t>(entry + kEntStride * (index & 0x1FF));
}

std::string ReadWeaponName(uintptr_t pawn, uintptr_t list) {
    (void)pawn; (void)list;
    return {}; // private
}


void CollectSpectators() {
    // Spectator resolution is private.
    g_spectators.clear();
}

void DrawSpectatorOverlay() {
    if (!g_specList) return;
    auto* dl = ImGui::GetBackgroundDrawList();
    const float x = (float)g_width - 230.f;
    float y = 72.f;
    char title[64];
    snprintf(title, sizeof(title), "Spectators (%d)", (int)g_spectators.size());
    dl->AddText(ImVec2(x, y), IM_COL32(80, 160, 255, 230), title);
    y += 18.f;
    if (g_spectators.empty()) {
        dl->AddText(ImVec2(x, y), IM_COL32(140, 150, 170, 180), "none");
        return;
    }
    for (const auto& n : g_spectators) {
        dl->AddText(ImVec2(x, y), IM_COL32(255, 220, 100, 255), n.c_str());
        y += 16.f;
    }
}

std::vector<Player> CollectPlayers() {
    // Entity walk / ESP data path is private.
    // Contact lyrickgg on Discord for the full source.
    return {};
}

// -------------------- draw --------------------
static void CornerBox(ImDrawList* dl, float x, float y, float w, float h, ImU32 col, float th) {
    float l = w * 0.25f;
    // top-left
    dl->AddLine(ImVec2(x, y), ImVec2(x + l, y), col, th);
    dl->AddLine(ImVec2(x, y), ImVec2(x, y + l), col, th);
    // top-right
    dl->AddLine(ImVec2(x + w, y), ImVec2(x + w - l, y), col, th);
    dl->AddLine(ImVec2(x + w, y), ImVec2(x + w, y + l), col, th);
    // bottom-left
    dl->AddLine(ImVec2(x, y + h), ImVec2(x + l, y + h), col, th);
    dl->AddLine(ImVec2(x, y + h), ImVec2(x, y + h - l), col, th);
    // bottom-right
    dl->AddLine(ImVec2(x + w, y + h), ImVec2(x + w - l, y + h), col, th);
    dl->AddLine(ImVec2(x + w, y + h), ImVec2(x + w, y + h - l), col, th);
}

void DrawESP(const std::vector<Player>& players) {
    auto* dl = ImGui::GetBackgroundDrawList();
    for (const auto& p : players) {
        if (!p.onScreen) continue;
        float h = p.screenFeet.y - p.screenHead.y;
        if (h < 4.f) continue;
        float w = h * 0.45f;
        float x = p.screenHead.x - w * 0.5f;
        float y = p.screenHead.y;

        ImU32 col = (p.team == 2)
            ? ImGui::ColorConvertFloat4ToU32(*(ImVec4*)g_enemyColor)
            : ImGui::ColorConvertFloat4ToU32(*(ImVec4*)g_teamColor);

        if (g_espBoxFilled)
            dl->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), (col & 0x00FFFFFF) | 0x40000000, 0.f);
        if (g_espBox) {
            if (g_espCorner) CornerBox(dl, x, y, w, h, col, g_boxThickness);
            else dl->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), col, 0.f, 0, g_boxThickness);
        }
        if (g_espHealth) {
            float frac = (std::min)(1.f, p.health / 100.f);
            float barH = h * frac;
            ImU32 hpCol = IM_COL32((int)(255 * (1.f - frac)), (int)(255 * frac), 40, 255);
            dl->AddRectFilled(ImVec2(x - 6.f, y + h - barH), ImVec2(x - 2.f, y + h), hpCol);
            dl->AddRect(ImVec2(x - 6.f, y), ImVec2(x - 2.f, y + h), IM_COL32(0, 0, 0, 160), 0.f, 0, 1.f);
        }
        if (g_espArmor && p.armor > 0) {
            float frac = (std::min)(1.f, p.armor / 100.f);
            float barH = h * frac;
            dl->AddRectFilled(ImVec2(x + w + 2.f, y + h - barH), ImVec2(x + w + 5.f, y + h), IM_COL32(80, 160, 255, 255));
        }

        float textY = y - 2.f;
        if (g_espName && !p.name.empty()) {
            ImVec2 ts = ImGui::CalcTextSize(p.name.c_str());
            textY -= ts.y;
            dl->AddText(ImVec2(p.screenHead.x - ts.x * 0.5f, textY),
                ImGui::ColorConvertFloat4ToU32(*(ImVec4*)g_nameColor), p.name.c_str());
        }
        if (g_espWeapon && !p.weapon.empty()) {
            ImVec2 ts = ImGui::CalcTextSize(p.weapon.c_str());
            dl->AddText(ImVec2(p.screenFeet.x - ts.x * 0.5f, p.screenFeet.y + 2.f),
                ImGui::ColorConvertFloat4ToU32(*(ImVec4*)g_weaponColor), p.weapon.c_str());
        }
        if (g_espDistance) {
            char buf[32];
            snprintf(buf, sizeof(buf), "%.0fm", p.distance);
            ImVec2 ts = ImGui::CalcTextSize(buf);
            float dy = p.screenFeet.y + (g_espWeapon ? 16.f : 2.f);
            dl->AddText(ImVec2(p.screenFeet.x - ts.x * 0.5f, dy), IM_COL32(180, 190, 210, 220), buf);
        }
        if (g_espSnapline)
            dl->AddLine(ImVec2(g_width * 0.5f, (float)g_height), ImVec2(p.screenFeet.x, p.screenFeet.y), col, 1.f);
    }
    if (g_drawFov) {
        // soft animated FOV ring
        float pulse = 0.85f + 0.15f * sinf(g_menuAnim * 2.f);
        dl->AddCircle(ImVec2(g_width * 0.5f, g_height * 0.5f), g_aimFov,
            IM_COL32(80, 140, 255, (int)(70 * pulse)), 32, 1.2f);
    }
}

void RunAimbot(const std::vector<Player>& players) {
    (void)players;
    // Aim logic is private.
}

// -------------------- menu --------------------
static bool NavBtn(const char* label, int id, float w) {
    bool selected = (g_menuTab == id);
    if (selected) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(g_accent[0], g_accent[1], g_accent[2], 0.85f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(g_accent[0] * 0.8f, g_accent[1] * 0.8f, g_accent[2], 1.f));
    } else {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.06f, 0.08f, 0.12f, 1.f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.10f, 0.14f, 0.22f, 1.f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.12f, 0.18f, 0.30f, 1.f));
    }
    bool clicked = ImGui::Button(label, ImVec2(w, 36.f));
    ImGui::PopStyleColor(3);
    if (clicked) g_menuTab = id;
    return clicked;
}

void DrawMenu() {
    float target = g_menuOpen ? 1.f : 0.f;
    g_menuAlpha += (target - g_menuAlpha) * 0.22f;
    if (g_menuAlpha < 0.02f && !g_menuOpen) return;

    if (g_styleDirty) {
        ApplyAzaroStyle();
        g_styleDirty = false;
    }
    ImGui::GetStyle().Alpha = g_menuAlpha;

    ImGui::SetNextWindowSize(ImVec2(460, 560), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(48, 48), ImGuiCond_FirstUseEver);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    if (!ImGui::Begin("##AzaroMain", &g_menuOpen,
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar)) {
        ImGui::PopStyleVar();
        ImGui::End();
        return;
    }
    ImGui::PopStyleVar();

    ImVec2 wp = ImGui::GetWindowPos();
    ImVec2 ws = ImGui::GetWindowSize();
    auto* dl = ImGui::GetWindowDrawList();

    // animated top gradient bar
    float pulse = 0.55f + 0.45f * sinf(g_menuAnim);
    ImU32 cA = IM_COL32(30, 90, 255, 255);
    ImU32 cB = IM_COL32((int)(20 + 40 * pulse), 40, 140, 255);
    dl->AddRectFilledMultiColor(wp, ImVec2(wp.x + ws.x, wp.y + 4.f), cA, cB, cB, cA);

    // soft outer glow
    dl->AddRect(ImVec2(wp.x - 1, wp.y - 1), ImVec2(wp.x + ws.x + 1, wp.y + ws.y + 1),
        IM_COL32(40, 100, 255, (int)(40 + 30 * pulse)), 10.f, 0, 1.5f);

    const float sideW = 118.f;
    // left sidebar bg
    dl->AddRectFilled(ImVec2(wp.x, wp.y + 4.f), ImVec2(wp.x + sideW, wp.y + ws.y),
        IM_COL32(8, 10, 16, 255), 0.f);

    // brand
    ImGui::SetCursorPos(ImVec2(14, 18));
    ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f), "AZARO");
    ImGui::SetCursorPosX(14);
    ImGui::TextDisabled("WARE");

    ImGui::SetCursorPos(ImVec2(10, 70));
    ImGui::BeginGroup();
    NavBtn("Visuals", 0, sideW - 20);
    NavBtn("Aimbot", 1, sideW - 20);
    NavBtn("Misc", 2, sideW - 20);
    NavBtn("Settings", 3, sideW - 20);
    NavBtn("Credits", 4, sideW - 20);
    ImGui::EndGroup();

    ImGui::SetCursorPos(ImVec2(14, ws.y - 48));
    ImGui::TextDisabled("%.0f fps", ImGui::GetIO().Framerate);

    // content panel
    ImGui::SetCursorPos(ImVec2(sideW + 12, 16));
    ImGui::BeginChild("content", ImVec2(ws.x - sideW - 24, ws.y - 28), true);

    if (g_menuTab == 0) {
        ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f), "ESP / Visuals");
        ImGui::Separator();
        ImGui::Checkbox("Box", &g_espBox);
        ImGui::SameLine(); ImGui::Checkbox("Filled", &g_espBoxFilled);
        ImGui::SameLine(); ImGui::Checkbox("Corners", &g_espCorner);
        ImGui::Checkbox("Health bar", &g_espHealth);
        ImGui::SameLine(); ImGui::Checkbox("Armor bar", &g_espArmor);
        ImGui::Checkbox("Name", &g_espName);
        ImGui::SameLine(); ImGui::Checkbox("Weapon", &g_espWeapon);
        ImGui::Checkbox("Distance", &g_espDistance);
        ImGui::SameLine(); ImGui::Checkbox("Snaplines", &g_espSnapline);
        ImGui::Checkbox("Hide teammates", &g_teamCheck);
        ImGui::SliderFloat("Thickness", &g_boxThickness, 0.5f, 4.f, "%.1f");
        ImGui::Spacing();
        ImGui::TextDisabled("Colors");
        ImGui::ColorEdit4("Enemy", g_enemyColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
        ImGui::SameLine();
        ImGui::ColorEdit4("Team", g_teamColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
        ImGui::ColorEdit4("Name##c", g_nameColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
        ImGui::SameLine();
        ImGui::ColorEdit4("Weapon##c", g_weaponColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
    }
    else if (g_menuTab == 1) {
        ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f), "Aimbot");
        ImGui::Separator();
        ImGui::Checkbox("Enable aimbot", &g_aimbot);
        ImGui::Checkbox("Draw FOV circle", &g_drawFov);
        ImGui::Checkbox("Aim at head", &g_aimHead);
        ImGui::SliderFloat("FOV (px)", &g_aimFov, 10.f, 500.f, "%.0f");
        ImGui::SliderFloat("Smooth", &g_aimSmooth, 1.f, 20.f, "%.1f");
        ImGui::Spacing();
        ImGui::TextDisabled("Hold Right Mouse Button to aim");
    }
        else if (g_menuTab == 2) {
        ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f), "Misc");
        ImGui::Separator();
        ImGui::Checkbox("Spectator list", &g_specList);
        ImGui::TextDisabled("Shows who is watching you (top-right)");
        ImGui::Spacing();
        ImGui::Text("Spectating you: %d", (int)g_spectators.size());
        for (const auto& n : g_spectators)
            ImGui::TextColored(ImVec4(1.f, 0.85f, 0.3f, 1.f), "  %s", n.c_str());
        ImGui::Separator();
        ImGui::Text("Players drawn: %d", g_lastPlayerCount);
        for (const auto& p : g_lastPlayers) {
            ImGui::Text("%s | %d HP | %s",
                p.name.empty() ? "?" : p.name.c_str(),
                p.health,
                p.weapon.empty() ? "-" : p.weapon.c_str());
        }
    }
    else if (g_menuTab == 3) {
        ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f), "Settings");
        ImGui::Separator();
        if (ImGui::ColorEdit4("Menu accent", g_accent, ImGuiColorEditFlags_NoInputs))
            g_styleDirty = true;
        ImGui::SliderInt("Overlay FPS cap", &g_overlayFps, 30, 144);
        ImGui::Checkbox("VSync overlay", &g_vsync);
        ImGui::TextDisabled("Keep overlay at 60 so CS2 stays smooth");
        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("Save config", ImVec2(-1, 32))) SaveConfig();
        if (ImGui::Button("Load config", ImVec2(-1, 32))) { LoadConfig(); g_styleDirty = true; }
        ImGui::TextWrapped("Config: %%APPDATA%%\\AzaroWare\\config.ini");
    }
    else {
        ImGui::TextColored(ImVec4(g_accent[0], g_accent[1], g_accent[2], 1.f), "Credits");
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Text("AzaroWare");
        ImGui::TextColored(ImVec4(0.4f, 0.75f, 1.f, 1.f), "by lyrickgg");
        ImGui::Spacing();
        ImGui::TextDisabled("CS2 external overlay");
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        if (ImGui::Button("Join Discord", ImVec2(-1, 40))) {
            ShellExecuteA(nullptr, "open", "https://discord.gg/UNGu6QpdX", nullptr, nullptr, SW_SHOWNORMAL);
        }
        ImGui::Spacing();
        ImGui::TextDisabled("discord.gg/UNGu6QpdX");
        ImGui::Spacing();
        ImGui::TextWrapped("Offsets: sezzyaep/CS2-OFFSETS");
        ImGui::TextWrapped("UI: Dear ImGui (MIT)");
    }

    ImGui::EndChild();
    ImGui::End();
    ImGui::GetStyle().Alpha = 1.f;
}

// -------------------- entry --------------------
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    if (!mem.Attach(L"cs2.exe")) {
        MessageBoxA(nullptr, "cs2.exe not found.\nStart CS2 first, run as Admin.", "AzaroWare", MB_ICONERROR);
        return 1;
    }
    LoadConfig();

    char buf[160];
    sprintf_s(buf, "AzaroWare by lyrickgg\nclient.dll = 0x%llX\nINSERT=menu  END=quit\nRMB=aimbot\ndiscord.gg/UNGu6QpdX",
        (unsigned long long)mem.clientBase);
    MessageBoxA(nullptr, buf, "AzaroWare", MB_OK | MB_ICONINFORMATION);

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0, 0, GetModuleHandle(nullptr),
        nullptr, nullptr, nullptr, nullptr, L"AzaroWareOverlay", nullptr };
    RegisterClassExW(&wc);

    g_width = GetSystemMetrics(SM_CXSCREEN);
    g_height = GetSystemMetrics(SM_CYSCREEN);

    g_hwnd = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
        wc.lpszClassName, L"AzaroWare",
        WS_POPUP, 0, 0, g_width, g_height,
        nullptr, nullptr, wc.hInstance, nullptr);
    SetLayeredWindowAttributes(g_hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);

    if (!CreateDeviceD3D(g_hwnd)) {
        MessageBoxA(nullptr, "D3D11 failed", "AzaroWare", MB_ICONERROR);
        CleanupDeviceD3D();
        UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }
    ShowWindow(g_hwnd, SW_SHOWDEFAULT);
    UpdateWindow(g_hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr; // no imgui.ini spam
    ApplyAzaroStyle();
    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    SetPriorityClass(GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS);
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);

    bool running = true;
    using clock = std::chrono::steady_clock;
    auto nextFrame = clock::now();

    while (running) {
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) running = false;
        }
        if (!running) break;

        // CAP overlay FPS — without this the overlay eats the GPU and CS2 drops to 20-40
        int cap = g_overlayFps;
        if (cap < 30) cap = 30;
        if (cap > 144) cap = 144;
        const auto budget = std::chrono::microseconds(1000000 / cap);
        auto now = clock::now();
        if (now < nextFrame)
            std::this_thread::sleep_until(nextFrame);
        nextFrame = clock::now() + budget;

        if (GetAsyncKeyState(VK_END) & 1) running = false;
        if (GetAsyncKeyState(VK_INSERT) & 1) {
            g_menuOpen = !g_menuOpen;
            LONG_PTR ex = GetWindowLongPtr(g_hwnd, GWL_EXSTYLE);
            if (g_menuOpen) SetWindowLongPtr(g_hwnd, GWL_EXSTYLE, ex & ~WS_EX_TRANSPARENT);
            else SetWindowLongPtr(g_hwnd, GWL_EXSTYLE, ex | WS_EX_TRANSPARENT);
        }

        ++g_frameCounter;
        g_menuAnim += 0.02f;

        auto players = CollectPlayers();
        if (g_espWeapon && !g_lastPlayers.empty()) {
            for (auto& p : players) {
                if (!p.weapon.empty()) continue;
                for (const auto& old : g_lastPlayers) {
                    if (old.name == p.name && !old.weapon.empty()) {
                        p.weapon = old.weapon;
                        break;
                    }
                }
            }
        }
        g_lastPlayerCount = (int)players.size();
        if (g_menuOpen || (g_frameCounter & 3) == 0)
            g_lastPlayers = players;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        if ((g_frameCounter % 10) == 0)
            CollectSpectators();

        RunAimbot(players);
        DrawESP(players);
        DrawSpectatorOverlay();
        DrawMenu();

        {
            auto* dl = ImGui::GetBackgroundDrawList();
            dl->AddText(ImVec2(12, 12), IM_COL32(80, 160, 255, 160), "AzaroWare | lyrickgg");
        }

        ImGui::Render();
        const float clear[4] = { 0, 0, 0, 1 };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(g_vsync ? 1 : 0, 0);
    }

    SaveConfig();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    DestroyWindow(g_hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    mem.Close();
    return 0;
}